package org.scoula.jdbc_ex;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

class ConnectionTest {

    // db 연결 테스트 메서드 정의
    // 메서드 단위로 기능 테스트 가능 (JUnit 라이브러리 사용)
    @Test
    @DisplayName("jdbc_ex 데이터베이스에 접속한다.")
    public void testConnection() throws SQLException, ClassNotFoundException {
        //JDBC 단계별 테스트
        // 1. jdbc 드라이버 세팅(로딩), jdbc connector

        Class.forName("com.mysql.cj.jdbc.Driver"); // 외부파일 연결
        System.out.println("1. jdbc 드라이버 세팅(로딩) 성공");

        // 2. db 연결
        // db 연결 시 필요한 데이터 : url(ip + port + db명), username, pw

      //  String url = "jdbc:mysql://127.0.0.1:3306/jdbc_ex";
        //String id = "scoula";
        //String password = "1234";

        //Connection conn = DriverManager.getConnection(url, id, password);
        //System.out.println("DB 연결 성공");
        //conn.close();
    }
}